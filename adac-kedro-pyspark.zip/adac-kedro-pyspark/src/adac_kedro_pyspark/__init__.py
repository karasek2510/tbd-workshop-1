"""adac-kedro-pyspark
"""

__version__ = "0.1"
