import pandas as pd
from pyspark.sql import Column
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.functions import regexp_replace
from pyspark.sql.types import DoubleType
import mlflow
import pandas as pd
from typing import Dict, Tuple
import numpy as np


def split_data(data: SparkDataFrame, parameters: Dict) -> Tuple:
    data = data.toPandas()
    random_sample = data.sample(n=50, random_state=parameters["random_state"])
    X_random = random_sample[parameters["features"]]
    y_random = random_sample["price"]
    return X_random, y_random

def inference_model(X_random: pd.DataFrame, y_random: pd.Series, parameters: Dict) -> pd.Series:
    logged_model = parameters["model"]
    regressor = mlflow.pyfunc.load_model(logged_model)
    y_pred = regressor.predict(X_random)
    return y_pred
    
def save_to_file(y_pred: pd.Series):
    np.savetxt('data/07_model_output/y_pred.csv', y_pred)