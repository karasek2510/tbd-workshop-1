from kedro.pipeline import Pipeline, node, pipeline

from .nodes import inference_model, split_data, save_to_file


def create_pipeline(**kwargs) -> Pipeline:
    return pipeline(
        [
            node(
                func=split_data,
                inputs=["model_input_table@spark", "params:model_options"],
                outputs=["X_random", "y_random"],
                name="split_data_node_v2",
            ),
            node(
                func=inference_model,
                inputs=["X_random", "y_random", "params:model_options"],
                outputs="y_pred",
                name="inference_model_node",
            ),
            node(
                func=save_to_file,
                inputs="y_pred",
                outputs=None,
                name="save_to_file_node",
            ),
        ]
    )
